package entity;

import main.GamePanel;
import main.UtilityTool;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

public class NPC_Old_Man extends Entity{
    public NPC_Old_Man(GamePanel gp) {
        super(gp);

        direction = "down";
        name = "old_man";
        speed = 1;
        getNPCImage();
        setDialogues();

        // Here is how to add collision rectangle or box XD
        solidArea.x = 0;        // X offset from sprite's left edge
        solidArea.y = 16;       // Y offset from sprite's top edge
        solidArea.width = gp.tileSize;   // Width of collision box
        solidArea.height = 35;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;


    }
    public void getNPCImage(){

        up1 = setup("/npc/oldman_up_1", gp.tileSize, gp.tileSize);
        up2 = setup("/npc/oldman_up_2", gp.tileSize, gp.tileSize);
        down1 = setup("/npc/oldman_down_1", gp.tileSize, gp.tileSize);
        down2 = setup("/npc/oldman_down_2", gp.tileSize, gp.tileSize);
        left1 = setup("/npc/oldman_left_1", gp.tileSize, gp.tileSize);
        left2 = setup("/npc/oldman_left_2", gp.tileSize, gp.tileSize);
        right1 = setup("/npc/oldman_right_1", gp.tileSize, gp.tileSize);
        right2 = setup("/npc/oldman_right_2", gp.tileSize, gp.tileSize);

    }
    public void setDialogues(){
        dialogues[0] = "Hello, lad.";
        dialogues[1] = "What's up my nigga!";
        dialogues[2] = "Hello there, wanna hit some black\nniggas with me?";
        dialogues[3] = "Bring it down Yow!!";
    }
    public void speak(){
        super.speak();

    }

    public void setAction(){
        /*
        actionLockCounter++;

        if(actionLockCounter == 120){
            Random random = new Random();
            int i = random.nextInt(100) + 1; // Randomizer

            if(i <=  25){
                direction = "up";
            }
            if(i > 25 && i <= 50){
                direction = "down";
            }
            if(i > 50 && i <= 75){
                direction = "right";
            }
            if(i > 75){
                direction = "left";
            }

            actionLockCounter = 0;
        }

         */

    }
}
