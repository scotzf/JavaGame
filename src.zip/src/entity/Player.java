package entity;
import main.*;
import object.*;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import object.Others;
import java.util.Random;

public class Player extends Entity{

    public KeyHanlder keyH;
    public final int screenX;
    public final int screenY;
    int standCounter = 0;
    public boolean attackCanceled = false;
    // var for Inventory
    public ArrayList<Others> inventory = new ArrayList<>();
    public ArrayList<Entity> equipment = new ArrayList<>();
    public final int inventorySize = 35;
    // Equipped Gear
    public Entity headGear, chestGear, legGear, bootsGear, mainHand, offHand;

    public Player(GamePanel gp, KeyHanlder keyH){

        super(gp);
        this.keyH = keyH;

        solidArea = new Rectangle(8, 16, 32, 32);

        screenX = gp.screenWidth/2 - gp.tileSize/2; // 768 / 2 - 48/2
        screenY = gp.screenHeight/2 - gp.tileSize/2;

        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY =solidArea.y;

        attackArea.width = 36;
        attackArea.height = 36;

        setDefaultValues();
        getPlayerImage();
        getPlayerAttackImage();
        setItems();
    }
    public void setDefaultValues(){

        worldX = 535;
        worldY = 480;
        direction = "down";

        // Status
        maxLife = 6;
        life = maxLife;
        level = 1;
        exp = 0;
        nextLevelExp = 5;
        coin = 0;
        speed = 3;
        attack = 1;
        defense = 1;
    }
    public void setItems(){

        inventory.add(new Potion(gp));
        equipment.add(new OBJ_Sword(gp));
        equipment.add(new OBJ_Chestplate(gp));
        equipment.add(new OBJ_Legplate(gp));
        equipment.add(new OBJ_Helmet(gp));
        equipment.add(new OBJ_Boots(gp));
        equipment.add(new OBJ_Shield(gp));
        equipment.add(new OBJ_Fishingrod(gp));
        equipment.add(new OBJ_Axe(gp));
        inventory.add(new Seed(gp));

    }
    // Fix these getter methods - they should calculate TOTAL stats
    public int getAttackValue(){
        int totalAttack = attack; // Start with base attack

        if(mainHand != null){
            totalAttack += mainHand.attackValue;
        }

        return totalAttack;
    }
    public int getDefenseValue(){
        int totalDefense = defense; // Start with base defense

        if(headGear != null){
            totalDefense += headGear.defenseValue;
        }
        if(chestGear != null){
            totalDefense += chestGear.defenseValue;
        }
        if(legGear != null){
            totalDefense += legGear.defenseValue;
        }
        if(offHand != null){
            totalDefense += offHand.defenseValue;
        }

        return totalDefense;
    }
    public int getSpeedValue(){
        int totalSpeed = speed; // Start with base speed

        if(bootsGear != null){
            totalSpeed += bootsGear.speedValue;
        }

        return totalSpeed;
    }
    public void getPlayerImage(){

            up1 = setup("/player/boy_up_1", gp.tileSize, gp.tileSize);
            up2 = setup("/player/boy_up_2", gp.tileSize, gp.tileSize);
            down1 = setup("/player/boy_down_1", gp.tileSize, gp.tileSize);
            down2 = setup("/player/boy_down_2", gp.tileSize, gp.tileSize);
            left1 = setup("/player/boy_left_1", gp.tileSize, gp.tileSize);
            left2 = setup("/player/boy_left_2", gp.tileSize, gp.tileSize);
            right1 = setup("/player/boy_right_1", gp.tileSize, gp.tileSize);
            right2 = setup("/player/boy_right_2", gp.tileSize, gp.tileSize);

    }
    public void getPlayerAttackImage(){

        attackUp1 = setup("/attack/boy_attack_up_1", gp.tileSize, gp.tileSize * 2);
        attackUp2 = setup("/attack/boy_attack_up_2", gp.tileSize, gp.tileSize * 2);
        attackDown1 = setup("/attack/boy_attack_down_1", gp.tileSize, gp.tileSize * 2);
        attackDown2 = setup("/attack/boy_attack_down_2", gp.tileSize, gp.tileSize * 2);
        attackLeft1 = setup("/attack/boy_attack_left_1", gp.tileSize * 2, gp.tileSize);
        attackLeft2 = setup("/attack/boy_attack_left_2", gp.tileSize * 2, gp.tileSize);
        attackRight1 = setup("/attack/boy_attack_right_1", gp.tileSize * 2, gp.tileSize);
        attackRight2 = setup("/attack/boy_attack_right_2", gp.tileSize * 2, gp.tileSize);

    }
    public void update(){
        if(attacking){
            attacking();
        }
        else if(keyH.upPressed || keyH.downPressed || keyH.rightPressed|| keyH.leftPressed || keyH.enterPressed){

            if(keyH.upPressed){
                direction = "up";
            }
            else if(keyH.downPressed){
                direction = "down";
            }
            else if(keyH.rightPressed){
                direction = "right";
            }
            else if(keyH.leftPressed){
                direction = "left";
            }

            collisionOn = false;
            gp.cChecker.checkTile(this);

            // Check equipment objects
            int objIndex = gp.cChecker.checkObject(this, true);
            pickUpEquipment(objIndex);

            // NEW: Check consumable items
            int itemIndex = gp.cChecker.checkItem(this, true);
            pickUpObject(itemIndex);

            // NPC collision here
            int npcIndex = gp.cChecker.checkEntity(this,gp.npc);
            interactNPC(npcIndex);

            // monster collision
            int monIndex = gp.cChecker.checkEntity(this, gp.monster);
            contactMonster(monIndex);

            // Check Event
            gp.eHandler.checkEvent();

            int currentSpeed = getSpeedValue();
            if(!collisionOn && !keyH.enterPressed){
                if(keyH.upPressed){
                    worldY -= currentSpeed;
                }
                else if(keyH.downPressed){
                    worldY += currentSpeed;
                }
                else if(keyH.rightPressed){
                    worldX += currentSpeed;
                }
                else if(keyH.leftPressed){
                    worldX -= currentSpeed;
                }
            }
            if(keyH.enterPressed && !attackCanceled){
                gp.playSE(5);
                attacking = true;
                spriteCounter = 0;
            }
            attackCanceled = false;
            gp.keyH.enterPressed = false;

            spriteCounter++;
            if(spriteCounter > 10){
                if(spriteNumber == 1){
                    spriteNumber = 2;
                }else if(spriteNumber == 2){
                    spriteNumber = 1;
                }
                spriteCounter = 0;
            }
        }
        if(gp.keyH.shotKeyPressed && !projectile.alive && shotAvailable == 30){
            projectile.set(worldX, worldY, direction, true, this);
            gp.projectileList.add(projectile);
            gp.playSE(10);
            shotAvailable = 0;
        }
        if(invincible){
            invincibleCounter++;
            if(invincibleCounter > 60){
                invincible = false;
                invincibleCounter = 0;
            }
        }
        if(shotAvailable < 30){
            shotAvailable++;
        }
    }
    public void attacking(){
        spriteCounter++;
        if(spriteCounter <= 5){
            spriteNumber = 1;
        }
        if(spriteCounter > 5 && spriteCounter <= 25){
            spriteNumber = 2;
            // Save the current position
            int currentWorldX = worldX;
            int currentWorldY = worldY;
            int solidAreaWidth = solidArea.width;
            int solidAreaHeight = solidArea.height;

            // Adjust position
            switch (direction){
                case"up" -> {
                    worldY -= attackArea.height;
                    break;
                }
                case"down" -> {
                    worldY += attackArea.height;
                    break;
                }
                case"left" -> {
                    worldX -= attackArea.width;
                    break;
                }
                case"right" -> {
                    worldX += attackArea.width;
                    break;
                }
            }
            // Attack area becomes solidArea
            solidArea.width = attackArea.width;
            solidArea.height = attackArea.height;
            // Check monster collision with the new position
            int monsterIndex = gp.cChecker.checkEntity(this, gp.monster);
            damageMonster(monsterIndex, attack);
            // Swapping after checking that the new solidArea or where the weapon was has collided with monster or whatnots
            worldX = currentWorldX;
            worldY = currentWorldY;
            solidArea.width = solidAreaWidth;
            solidArea.height = solidAreaHeight;
        }
        if(spriteCounter > 25){
            spriteNumber = 1;
            spriteCounter = 0;
            attacking = false;
        }
    }
    public void pickUpObject(int index){
        if(index != 999){
            String text = "";

            if(gp.obj[index].pickupable){
                if(inventory.size() < inventorySize){
                    inventory.add(gp.obj[index]);
                    gp.playSE(2);
                    text = "Got a " + gp.obj[index].name + "!";
                } else {
                    text = "Inventory full!";
                }
                gp.ui.addMessage(text);
                gp.obj[index] = null;
            }
        }
    }
    public void pickUpEquipment(int index){
        if(index != 999){
            String text = "";
            if(equipment.size() < inventorySize){
                equipment.add(gp.eqp[index]);  // Need gp.equipmentObj[] array
                gp.playSE(2);
                text = "Got a " + gp.eqp[index].name;
            } else {
                text = "Equipment storage full!";
            }
            gp.ui.addMessage(text);
            gp.eqp[index] = null;
        }
    }
    public void interactNPC(int index){
        if(keyH.enterPressed){
            if(index != 999){
                attackCanceled = true;
                gp.gameState = gp.dialogueState;
                gp.npc[index].speak();
            }
        }

    }
    public void draw(Graphics2D g2){
        BufferedImage image = null;
        int tempScreenX = screenX;
        int tempScreenY = screenY;

        switch(direction){
            case "up" -> {
                if(!attacking){
                    if(spriteNumber == 1){
                        image = up1;
                    }
                    if(spriteNumber == 2){
                        image = up2;
                    }
                }
                if(attacking){
                    tempScreenY = screenY - gp.tileSize;
                    if(spriteNumber == 1){
                        image = attackUp1;
                    }
                    if(spriteNumber == 2){
                        image = attackUp2;
                    }
                }
                break;
            }
            case "down" -> {
                if(!attacking){
                    if(spriteNumber == 1){
                        image = down1;
                    }
                    if(spriteNumber == 2){
                        image = down2;
                    }
                }
                if(attacking){
                    if(spriteNumber == 1){
                        image = attackDown1;
                    }
                    if(spriteNumber == 2){
                        image = attackDown2;
                    }
                }
                break;
            }
            case "left" -> {
                if(!attacking){
                    if(spriteNumber == 1){
                        image = left1;
                    }
                    if(spriteNumber == 2){
                        image = left2;
                    }
                }
                if(attacking){
                    tempScreenX = screenX - gp.tileSize;
                    if(spriteNumber == 1){
                        image = attackLeft1;
                    }
                    if(spriteNumber == 2){
                        image = attackLeft2;
                    }
                }
                break;
            }
            case "right" -> {
                if(!attacking){
                    if(spriteNumber == 1){
                        image = right1;
                    }
                    if(spriteNumber == 2){
                        image = right2;
                    }
                }
                if(attacking){
                    if(spriteNumber == 1){
                        image = attackRight1;
                    }
                    if(spriteNumber == 2){
                        image = attackRight2;
                    }
                }
                break;
            }
        }
        if(invincible && gp.gameState != gp.dialogueState){
             changeAlpha(g2,0.4f);
        }
        g2.drawImage(image, tempScreenX, tempScreenY, null);

    }
    // When taking damage, use the getter method
    public void contactMonster(int i){
        if(i != 999){
            if(!invincible && !gp.monster[i].dying){
                int damage = gp.monster[i].attack - getDefenseValue(); // Use getter!
                if(damage < 0){
                    damage = 0;
                }
                life -= damage;
                invincible = true;
                gp.playSE(6);
            }
        }
    }
    // When dealing damage, use the getter methods
    public void damageMonster(int i, int attack){
        if(i != 999){
            if(!gp.monster[i].invincible){
                gp.playSE(7);

                int damage = getAttackValue() - gp.monster[i].defense; // Use getter!
                if(damage < 0){
                    damage = 0;
                }
                gp.monster[i].life -= damage;
                gp.ui.addMessage(damage+ " Damage!");
                gp.monster[i].damageReaction();
                gp.monster[i].invincible = true;
                if(gp.monster[i].life <= 0){
                    gp.monster[i].dying = true;
                    gp.ui.addMessage("Killed "+ gp.monster[i].name+"!");
                    exp += gp.monster[i].exp;
                    gp.ui.addMessage("Gained "+gp.monster[i].exp+" exp!");
                    checkLevelUp();
                }
            }
        }
    }
    public void checkLevelUp(){
        if(gp.player.exp >= gp.player.nextLevelExp){
            gp.playSE(8);
            level++;
            nextLevelExp = nextLevelExp + 5;
            maxLife += 2;
            life += 2;
            attack += 2;
            defense += 2;
            gp.gameState = gp.dialogueState;
            gp.ui.currentDialogue = "You are level "+ level + " now!\n"
                                        + " You feel stronger!";
        }
    }
    public void selectItem(int i){
        if(i == 1){
            int itemIndex = gp.ui.getItemIndex();
            if(itemIndex < inventory.size()) {
                Others selectedItem = inventory.get(itemIndex);
                if (selectedItem.consumable) {
                    boolean success = selectedItem.use();  // Get result
                    if(success) {  // Only remove if successful
                        inventory.remove(itemIndex);
                    }
                }
            }
        }
        if(i == 0){
            int itemIndex = gp.ui.getItemIndex();
            if(itemIndex < equipment.size()){
                Entity selectedItem = equipment.get(itemIndex);

                // Just toggle equip/unequip - no manual stat calculation needed!
                if(selectedItem.placementEquip == 1){
                    headGear = (headGear == selectedItem) ? null : selectedItem;
                }
                else if(selectedItem.placementEquip == 2){
                    chestGear = (chestGear == selectedItem) ? null : selectedItem;
                }
                else if(selectedItem.placementEquip == 3){
                    legGear = (legGear == selectedItem) ? null : selectedItem;
                }
                else if(selectedItem.placementEquip == 4){
                    // Main hand (one-handed weapon)
                    if(mainHand == selectedItem) {
                        mainHand = null;
                    } else {
                        // Check BEFORE changing mainHand if we have a two-handed weapon
                        if(mainHand != null && mainHand == offHand) {
                            offHand = null; // Clear the two-handed weapon from offHand
                        }
                        mainHand = selectedItem; // Now equip the new one-handed weapon
                    }
                }
                else if(selectedItem.placementEquip == 5){
                    // Off hand (shield)
                    if(offHand == selectedItem) {
                        offHand = null;
                    } else {
                        // Check BEFORE changing offHand if we have a two-handed weapon
                        if(offHand != null && mainHand == offHand) {
                            mainHand = null; // Clear the two-handed weapon from mainHand
                        }
                        offHand = selectedItem; // Now equip the new shield
                    }
                }
                else if(selectedItem.placementEquip == 6){
                    bootsGear = (bootsGear == selectedItem) ? null : selectedItem;
                }
                else if(selectedItem.placementEquip == 7){
                    // Check if already equipped
                    if(mainHand == selectedItem && offHand == selectedItem) {
                        // Unequip both
                        mainHand = null;
                        offHand = null;
                    } else {
                        // Equip both
                        mainHand = selectedItem;
                        offHand = selectedItem;
                    }
                }

                // Stats are automatically calculated when you call the getter methods!
            }
        }
    }
    public void harvestCrop() {
        System.out.println("Harvest key pressed!");
        // Calculate which tile the player is facing
        int playerCol = (worldX + solidArea.x) / gp.tileSize;
        int playerRow = (worldY + solidArea.y) / gp.tileSize;

        // Check the tile in front of the player based on direction
        int targetCol = playerCol;
        int targetRow = playerRow;

        switch(direction) {
            case "up" -> targetRow--;
            case "down" -> targetRow++;
            case "left" -> targetCol--;
            case "right" -> targetCol++;
        }

        // Bounds check
        if(targetCol < 0 || targetCol >= gp.maxWorldCol ||
                targetRow < 0 || targetRow >= gp.maxWorldRow) {
            return;
        }

        // Get the tile number at target location
        int tileNum = gp.tileM.mapTileNumber[gp.currentMap][targetCol][targetRow];
        System.out.println("Facing tile: " + tileNum);  // Debug

        // Check if it's a fully grown crop (tile 56, 60, or 64) - FIXED!
        if(tileNum == 56 || tileNum == 60 || tileNum == 64) {
            // Check if there's actually a plant here
            Plant plant = gp.plantManager.getPlantAt(targetCol, targetRow);

            if(plant != null && plant.isFullyGrown()) {
                // Random number generator
                Random random = new Random();

                // Give 1-3 Fruits
                int fruitAmount = random.nextInt(3) + 1;
                for(int i = 0; i < fruitAmount; i++) {
                    if(inventory.size() < inventorySize) {
                        inventory.add(new Fruit(gp));
                    }
                }

                // Give 1-2 Seeds
                int seedAmount = random.nextInt(2) + 1;
                for(int i = 0; i < seedAmount; i++) {
                    if(inventory.size() < inventorySize) {
                        inventory.add(new Seed(gp));
                    }
                }

                // Play harvest sound
                gp.playSE(2);

                // Show message
                gp.ui.addMessage("Harvested! +" + fruitAmount + " Fruit, +" + seedAmount + " Seed");

                // Reset tile back to original plot type - FIXED!
                gp.tileM.mapTileNumber[gp.currentMap][targetCol][targetRow] = plant.originalPlotType;

                // Remove plant from manager
                gp.plantManager.removePlant(targetCol, targetRow);

                // Check if inventory is full
                if(inventory.size() >= inventorySize) {
                    gp.ui.addMessage("Inventory full! Some items lost!");
                }
            }
        }
    }
}
