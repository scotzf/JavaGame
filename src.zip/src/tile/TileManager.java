package tile;

import main.GamePanel;
import main.UtilityTool;
import javax.imageio.ImageIO;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TileManager {

    GamePanel gp;
    public Tile[] tile;
    public int[][][] mapTileNumber;  // 3D array
    public int maxMaps = 10;  // ADD THIS

    public TileManager(GamePanel gp){
        this.gp = gp;

        tile = new Tile[100];
        mapTileNumber = new int[maxMaps][gp.maxWorldCol][gp.maxWorldRow];  // FIXED: 3D array initialization
        getTileImage();
        loadAllMaps();  // FIXED: Load all maps
    }

    // FIXED: New method to load all maps
    public void loadAllMaps(){
        loadMap("/maps/map01.txt", 0);  // Main world
        loadMap("/maps/map00.txt", 1);  // House
        loadMap("/maps/map02.txt", 2);  // Cave
    }

    public void getTileImage(){
        setUpTile(0, "dirtH", false);
        setUpTile(1, "dirtH", false);
        setUpTile(2, "dirtH", false);
        setUpTile(3, "dirtH", false);
        setUpTile(4, "dirtH", false);
        setUpTile(5, "dirtH", false);
        setUpTile(6, "dirtH", false);
        setUpTile(7, "dirtH", false);
        setUpTile(8, "dirtH", false);
        setUpTile(9, "dirtH", false);
        setUpTile(10, "grass_grass", false);
        setUpTile(11, "grass_dirt", false);
        setUpTile(12, "tree", true);
        setUpTile(13, "plot_top", false);
        setUpTile(14, "plot", false);
        setUpTile(15, "plot_bottom", false);
        setUpTile(16, "dirt", false);
        setUpTile(17, "dirt_road", false);
        setUpTile(18, "dirt_start", false);
        setUpTile(19, "dirt_startH", false);
        setUpTile(20, "dirt_roadH", false);
        setUpTile(21, "dirtH", false);
        setUpTile(22, "pond_bLeft", true);
        setUpTile(23, "pond_mLeft1", true);
        setUpTile(24, "pond_tLeft1", true);
        setUpTile(25, "pond_tMiddle", true);
        setUpTile(26, "pond-tRight", true);
        setUpTile(27, "pond-bMiddle", true);
        setUpTile(28, "pond-bRight", true);
        setUpTile(29, "pond-mRight", true);
        setUpTile(30, "river_baseHL", true);
        setUpTile(31, "river_baseHR", true);
        setUpTile(32, "river_baseV", true);
        setUpTile(33, "river_baseVU", true);
        setUpTile(34, "river_end", true);
        setUpTile(35, "river_endVL", true);
        setUpTile(36, "river_endVR", true);
        setUpTile(38, "plain_water", true);
        setUpTile(39, "grass_grass", false);
        setUpTile(40, "top_left", true);
        setUpTile(41, "top_right", true);
        setUpTile(42, "bot_left", true);
        setUpTile(43, "bot_right", true);
        setUpTile(44, "grass_grass", false);
        setUpTile(45, "grass_grass", false);
        setUpTile(46, "grass_grass", false);
        setUpTile(47, "grass_grass", false);
        setUpTile(48, "grass_grass", false);
        setUpTile(49, "cliff", true);
        setUpTile(50, "cliff_lEdge", true);
        setUpTile(51, "cliff_rEdge", true);
        setUpTile(52, "cliff_dungeon", true);

        // Plot Top growth phases
        setUpTile(53, "plot_top_seed", false);
        setUpTile(54, "plot_top_sprout", false);
        setUpTile(55, "plot_top_youngPlant", false);
        setUpTile(56, "plot_top_mature", false);

        // Plot Middle growth phases
        setUpTile(57, "plot_seed", false);
        setUpTile(58, "plot_sprout", false);
        setUpTile(59, "plot_youngPlant", false);
        setUpTile(60, "plot_mature", false);

        // Plot Bottom growth phases
        setUpTile(61, "plot_bottom_seed", false);
        setUpTile(62, "plot_bottom_sprout", false);
        setUpTile(63, "plot_bottom_youngPlant", false);
        setUpTile(64, "plot_bottom_mature", false);
    }

    public void setUpTile(int index, String loc, boolean collision){
        UtilityTool uTool = new UtilityTool();
        try {
            tile[index] = new Tile();
            tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/" + loc+ ".png"));
            tile[index].image = uTool.scaleImage(tile[index].image, gp.tileSize,gp.tileSize);
            tile[index].collision = collision;
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    // FIXED: Added mapIndex parameter
    public void loadMap(String filePath, int mapIndex){
        try{
            InputStream is = getClass().getResourceAsStream(filePath);
            BufferedReader br = new BufferedReader(new InputStreamReader(is));

            int col = 0;
            int row = 0;

            while(row < gp.maxWorldRow){
                String line = br.readLine();
                if(line == null) break;

                String numbers[] = line.split(" ");
                col = 0;

                while(col < gp.maxWorldCol && col < numbers.length){
                    int num = Integer.parseInt(numbers[col]);
                    mapTileNumber[mapIndex][col][row] = num;  // FIXED: Added mapIndex
                    col++;
                }
                row++;
            }
            br.close();
        }catch(Exception e){
            System.out.println("Error loading map " + mapIndex + ":");
            e.printStackTrace();
        }
    }

    public void draw(Graphics2D g2){
        int worldCol = 0;
        int worldRow = 0;

        while(worldCol < gp.maxWorldCol && worldRow < gp.maxWorldRow){
            int tileNum = mapTileNumber[gp.currentMap][worldCol][worldRow];  // FIXED: Added gp.currentMap

            int worldX = worldCol * gp.tileSize;
            int worldY = worldRow * gp.tileSize;
            int screenX = worldX - gp.player.worldX + gp.player.screenX;
            int screenY = worldY - gp.player.worldY + gp.player.screenY;

            if(worldX + gp.tileSize> gp.player.worldX - gp.player.screenX &&
                    worldX - gp.tileSize< gp.player.worldX + gp.player.screenX &&
                    worldY + gp.tileSize> gp.player.worldY - gp.player.screenY &&
                    worldY - gp.tileSize< gp.player.worldY + gp.player.screenY){

                g2.drawImage(tile[tileNum].image, screenX, screenY, null);
            }

            worldCol++;

            if(worldCol == gp.maxWorldCol){
                worldCol = 0;
                worldRow++;
            }
        }
    }
}