package object;

import main.GamePanel;

public class Potion extends Others {

    public Potion(GamePanel gp) {
        super(gp);

        name = "Health Potion";
        consumable = true;
        pickupable = true;
        collision = false; // Important: items should not block movement

        // The path is /objects/potion_red (without .png extension)
        // The setup method adds .png automatically
        setItemImage(setup("/objects/potion_red", gp.tileSize, gp.tileSize));
        setDescription("Restores 2 \nhearts of health.");
    }

    @Override
    public boolean use() {
        gp.gameState = gp.playState;
        gp.player.life += 4;

        if(gp.player.life > gp.player.maxLife) {
            gp.player.life = gp.player.maxLife;
        }

        gp.playSE(2);
        gp.ui.addMessage("Used Health Potion!");
        return true;  // Successfully  used
    }
}