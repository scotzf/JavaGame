package object;

import entity.Entity;
import main.GamePanel;
import java.awt.image.BufferedImage;

public class Others extends Entity {

    public boolean consumable;
    public boolean pickupable;
    // Keep itemImage as an alias for compatibility with UI code
    public BufferedImage itemImage;
    // Keep description as an alias
    public String description;

    public Others(GamePanel gp){
        super(gp);
        // Set default solid area for items
        solidArea.x = 0;
        solidArea.y = 0;
        solidArea.width = 48;
        solidArea.height = 48;
        solidAreaDefaultX = solidArea.x;
        solidAreaDefaultY = solidArea.y;
    }

    // Helper method to sync itemImage with the Entity's image field
    protected void setItemImage(BufferedImage img){
        this.image = img;
        this.itemImage = img;
    }

    // Helper method to sync description with itemDescription
    protected void setDescription(String desc){
        this.itemDescription = desc;
        this.description = desc;
    }

    @Override
    public boolean use(){
        return true;  // Override in specific item classes
    }

    @Override
    public void draw(java.awt.Graphics2D g2){
        // Items use the standard Entity draw, but we can customize if needed
        if(image != null){
            int screenX = worldX - gp.player.worldX + gp.player.screenX;
            int screenY = worldY - gp.player.worldY + gp.player.screenY;

            if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX &&
                    worldX - gp.tileSize < gp.player.worldX + gp.player.screenX &&
                    worldY + gp.tileSize > gp.player.worldY - gp.player.screenY &&
                    worldY - gp.tileSize < gp.player.worldY + gp.player.screenY){

                g2.drawImage(image, screenX, screenY, null);
            }
        }
    }
}