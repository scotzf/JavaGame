package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Legplate extends Entity {
    public OBJ_Legplate(GamePanel gp){
        super(gp);

        name = "Legplate";
        down1 = setup("/objects/legplate", gp.tileSize, gp.tileSize);
        defenseValue = 1;
        itemDescription = "Name: "+name+ "\n Just a normal \nlegplate!";
        placementEquip = 3;
    }

}
