package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Helmet extends Entity {
    public OBJ_Helmet(GamePanel gp){
        super(gp);

        name = "Helmet";
        down1 = setup("/objects/helmet", gp.tileSize, gp.tileSize);
        defenseValue = 1;
        itemDescription = "Name: "+name+ "\n Just a normal \nhelmet!";
        placementEquip = 1;
    }

}
