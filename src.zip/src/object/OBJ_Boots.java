package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Boots extends Entity {
    public OBJ_Boots(GamePanel gp){
        super(gp);

        name = "Boots";
        down1 = setup("/objects/boots", gp.tileSize, gp.tileSize);
        speedValue = 3;
        itemDescription = "["+name+"]"+"\n Just a normal \n Boots!";
        placementEquip = 6;
    }

}
