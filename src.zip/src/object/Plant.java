package object;

import main.GamePanel;

public class Plant {

    GamePanel gp;
    public int col;  // Which column (tile X position)
    public int row;  // Which row (tile Y position)
    public int growthStage;  // 1, 2, 3, or 4 (harvestable)
    public int growthTimer;  // Frames until next growth stage
    public int timePerStage = 1800;  // 30 seconds at 60 FPS (adjust this!)
    public int originalPlotType;  // ADD THIS LINE - Store which plot type (13, 14, or 15)

    public Plant(GamePanel gp, int col, int row, int originalPlotType) {  // ← ADD 4th parameter
        this.gp = gp;
        this.col = col;
        this.row = row;
        this.growthStage = 1;
        this.growthTimer = timePerStage;
        this.originalPlotType = originalPlotType;  // ADD THIS LINE
    }

    public void update() {
        if(growthStage < 4) {  // Not fully grown yet
            growthTimer--;

            if(growthTimer <= 0) {
                growthStage++;
                growthTimer = timePerStage;  // Reset timer for next stage
                updateTile();
            }
        }
    }

    private void updateTile() {
        // Change the tile based on growth stage AND original plot type
        int baseIndex = 0;

        // Determine base index based on original plot type
        if(originalPlotType == 13) {  // plot_top
            baseIndex = 53;  // plot_top_seed, plot_top_sprout, plot_top_youngPlant, plot_top_mature
        } else if(originalPlotType == 14) {  // plot (middle)
            baseIndex = 57;  // plot_seed, plot_sprout, plot_youngPlant, plot_mature
        } else if(originalPlotType == 15) {  // plot_bottom
            baseIndex = 61;  // plot_bottom_seed, plot_bottom_sprout, plot_bottom_youngPlant, plot_bottom_mature
        }

        // Set tile based on growth stage
        switch(growthStage) {
            case 1 -> gp.tileM.mapTileNumber[gp.currentMap][col][row] = baseIndex;      // seed
            case 2 -> gp.tileM.mapTileNumber[gp.currentMap][col][row] = baseIndex + 1;  // sprout
            case 3 -> gp.tileM.mapTileNumber[gp.currentMap][col][row] = baseIndex + 2;  // youngPlant
            case 4 -> gp.tileM.mapTileNumber[gp.currentMap][col][row] = baseIndex + 3;  // mature
        }
    }

    public boolean isFullyGrown() {
        return growthStage >= 4;
    }
}