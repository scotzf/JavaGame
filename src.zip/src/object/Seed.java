package object;

import main.GamePanel;

public class Seed extends Others {

    public Seed(GamePanel gp) {
        super(gp);

        name = "Seed";
        consumable = true;  // Gets consumed when planted
        pickupable = true;
        collision = false;

        // Load seed image - adjust path to match your resources folder
        setItemImage(setup("/objects/seed", gp.tileSize, gp.tileSize));
        setDescription("Plant on tilled soil\nto grow crops.");
    }

    @Override
    public boolean use() {
        return plant();  // Return the result of plant()
    }

    public boolean plant() {
        // Calculate which tile the player is standing on
        int playerCol = (gp.player.worldX + gp.player.solidArea.x) / gp.tileSize;
        int playerRow = (gp.player.worldY + gp.player.solidArea.y) / gp.tileSize;

        // Check the tile in front of the player based on direction
        int targetCol = playerCol;
        int targetRow = playerRow;

        switch(gp.player.direction) {
            case "up" -> targetRow--;
            case "down" -> targetRow++;
            case "left" -> targetCol--;
            case "right" -> targetCol++;
        }

        // Bounds check
        if(targetCol < 0 || targetCol >= gp.maxWorldCol ||
                targetRow < 0 || targetRow >= gp.maxWorldRow) {
            gp.ui.addMessage("Can't plant there!");
            gp.gameState = gp.playState;
            return false;  // FIXED: Added false
        }

        // Get the tile number at target location
        int tileNum = gp.tileM.mapTileNumber[gp.currentMap][targetCol][targetRow];

        // Check if it's a valid plot (13, 14, or 15)
        if(tileNum == 13 || tileNum == 14 || tileNum == 15) {

            // Check if there's already a plant here
            if(gp.plantManager.isPlantAt(targetCol, targetRow)) {
                gp.ui.addMessage("Already planted here!");
                gp.gameState = gp.playState;
                return false;  // Failed to plant
            }

            // Plant the seed!
            gp.plantManager.addPlant(targetCol, targetRow, tileNum);
            gp.ui.addMessage("Planted seed!");
            gp.playSE(2);
            gp.gameState = gp.playState;
            return true;  // Successfully planted!

        } else {
            gp.ui.addMessage("Must plant on tilled soil!");
            gp.gameState = gp.playState;
            return false;  // Failed to plant
        }
    }
}