package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Chestplate extends Entity {
    public OBJ_Chestplate(GamePanel gp){
        super(gp);

        name = "Chestplate";
        down1 = setup("/objects/chestplate", gp.tileSize, gp.tileSize);
        defenseValue = 2;
        itemDescription = "["+name+"]"+ "\n Just a normal \nchestplate!";
        placementEquip = 2;
    }

}
