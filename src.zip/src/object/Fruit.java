package object;

import main.GamePanel;

public class Fruit extends Others {

    public Fruit(GamePanel gp) {
        super(gp);

        name = "Fruit";
        consumable = true;
        pickupable = true;
        collision = false; // Items should not block movement

        // Load fruit image - adjust path to match your resources folder
        // Common paths: /objects/fruit, /items/fruit, /object/apple, etc.
        setItemImage(setup("/objects/fruit", gp.tileSize, gp.tileSize));
        setDescription("A delicious fruit.\nRestores 10 HP.");
    }

    @Override
    public boolean use() {
        gp.gameState = gp.playState;
        gp.player.life += 10;

        if(gp.player.life > gp.player.maxLife) {
            gp.player.life = gp.player.maxLife;
        }

        gp.playSE(2);
        gp.ui.addMessage("Ate " + name + "! +10 HP");
        return true;  // Successfully used
    }
}