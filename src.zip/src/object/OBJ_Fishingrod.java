package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Fishingrod extends Entity {
    public OBJ_Fishingrod(GamePanel gp){
        super(gp);

        name = "Fishing Rod";
        down1 = setup("/objects/fishing_rod", gp.tileSize, gp.tileSize);
        itemDescription = "["+name+"]"+ "\n For Fishing \nObviously";
        placementEquip = 7;
    }

}
